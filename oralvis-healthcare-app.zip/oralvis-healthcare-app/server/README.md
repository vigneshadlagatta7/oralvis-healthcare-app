# OralVis Healthcare – Server

## Quick start
```bash
cd server
cp .env.example .env
npm install
npm run dev
```

Defaults create two users:
- technician@example.com / password (role: TECHNICIAN)
- dentist@example.com / password (role: DENTIST)

### API
- `POST /api/auth/login` → { token, role }
- `POST /api/scans` (TECHNICIAN, multipart/form-data) fields: patientName, patientId, scanType, region, image
- `GET /api/scans` (DENTIST)
- `GET /api/scans/:id` (DENTIST)
- `GET /api/scans/:id/report.pdf` (DENTIST)
