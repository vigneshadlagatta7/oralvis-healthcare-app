import sqlite3 from 'sqlite3';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
dotenv.config();

const dbPath = process.env.DATABASE_URL || './data.db';
const db = new sqlite3.Database(dbPath);

// initialize tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('TECHNICIAN','DENTIST'))
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patientName TEXT NOT NULL,
    patientId TEXT NOT NULL,
    scanType TEXT NOT NULL,
    region TEXT NOT NULL,
    imageUrl TEXT NOT NULL,
    createdAt TEXT NOT NULL
  )`);

  // Seed default users if not exist
  db.get("SELECT COUNT(*) as count FROM users", (err, row) => {
    if (err) { console.error(err); return; }
    if (row.count === 0) {
      const password = bcrypt.hashSync('password', 10);
      const stmt = db.prepare("INSERT INTO users (email, password, role) VALUES (?,?,?)");
      stmt.run('technician@example.com', password, 'TECHNICIAN');
      stmt.run('dentist@example.com', password, 'DENTIST');
      stmt.finalize(() => console.log('Seeded default users.'));
    }
  });
});

export default db;
