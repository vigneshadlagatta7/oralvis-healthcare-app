# OralVis Healthcare – Client

## Quick start
```bash
cd client
npm install
npm run dev
```

Create a `.env` (optional):
```
VITE_API_BASE=http://localhost:4000
```
